<h4><php _e('Help', 'wpCASificator'); ?></h4>
<img src="<?php echo CAS_MAESTRO_PLUGIN_URL?>/images/ist_logo.png"/>